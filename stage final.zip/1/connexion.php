<?php
$connexion = mysqli_connect("localhost", "root", "", "gestion_evenement") or die("Erreur de connexion: " . mysqli_error($connexion));

?>