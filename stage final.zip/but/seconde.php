<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="color:white" class="bg-info">
      <div class="container-fluid">
     
  <div class="row">
    <div class="col-md-2 bg-success" >.col-md-2</div>
    <div class="col-md-5 offset-md-5 bg-primary">.col-md-4 .offset-md-4</div>
  </div>

  <div class="row">
      <div class="col-md-2 offset-md-2" style="background-color:red">2</div>
      <div class="col-md-8"  style="background-color:white">2</div>
  </div>
        
  <div class="row">
      <div class="col-md-2 offset-md-10" style="background-color:red">2</div>
  </div>

  <div class="row">
      <div class="col-md-4 offset-md-4" style="background-color:gold">2</div>
  </div>
</div>

        
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>