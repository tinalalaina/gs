<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login | user</title>
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:black">
<div class="container">
    <div class="row">
        <div class="col-sm-12 text-center " style="background-color:gold;color:white" > <h1>Géstion d'évènement</h1></div>
        <div class="col-sm-8 bg-primary text-center">1</div>
        <div class="col-sm-4 bg-success text-center">

        <div class="card">
  <div class="card-body">
  <div class="form-group">
  <label for="usr">Utilisateur:</label>
  <input type="text" class="form-control" id="usr">
</div>
<div class="form-group">
  <label for="pwd">Mot de passe:</label>
  <input type="password" class="form-control" id="pwd">
</div>
<div class="form-group">
<input class="btn btn-primary" type="submit" value="Confirmer">
</div>
  </div>
        </div>
        
        </div>
        <div class="col-sm-12 text-center" style="color:red;background-color:gold">2022-2027</div>
    </div>
</div>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>