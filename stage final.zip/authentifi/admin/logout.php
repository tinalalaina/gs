<?php
session_start();
session_destroy();
?>

exemple
<script language="javascript">
document.location="../../index.php";
</script>
